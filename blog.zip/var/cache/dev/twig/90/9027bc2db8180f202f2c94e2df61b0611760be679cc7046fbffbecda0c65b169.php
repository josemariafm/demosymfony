<?php

/* lucky/number.html.twig */
class __TwigTemplate_bd9672def6c0b7f6c36ae8b4f270d4fc74c662e835caa8cd1bab0bff27dfc2c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_00a85cf9cda5ac77cc5b24a97cc4ffc334643e9748fc435119f9732f29aab066 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00a85cf9cda5ac77cc5b24a97cc4ffc334643e9748fc435119f9732f29aab066->enter($__internal_00a85cf9cda5ac77cc5b24a97cc4ffc334643e9748fc435119f9732f29aab066_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "lucky/number.html.twig"));

        // line 2
        echo "
<h1>Your lucky number is ";
        // line 3
        echo twig_escape_filter($this->env, ($context["number"] ?? $this->getContext($context, "number")), "html", null, true);
        echo "</h1>";
        
        $__internal_00a85cf9cda5ac77cc5b24a97cc4ffc334643e9748fc435119f9732f29aab066->leave($__internal_00a85cf9cda5ac77cc5b24a97cc4ffc334643e9748fc435119f9732f29aab066_prof);

    }

    public function getTemplateName()
    {
        return "lucky/number.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 3,  22 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# app/Resources/views/lucky/number.html.twig #}

<h1>Your lucky number is {{ number }}</h1>", "lucky/number.html.twig", "C:\\inetpub\\wwwroot\\symfony\\blog\\app\\Resources\\views\\lucky\\number.html.twig");
    }
}
